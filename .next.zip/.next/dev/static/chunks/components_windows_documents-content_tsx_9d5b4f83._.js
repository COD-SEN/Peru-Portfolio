(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d4d60651._.js",
  "static/chunks/components_windows_documents-content_tsx_dfb8dbd4._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/windows/profile-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_0630fa31._.js",
  "static/chunks/components_windows_profile-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/profile-content.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/components/windows/projects-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_677a1f75._.js",
  "static/chunks/components_windows_projects-content_tsx_b3837985._.js",
  "static/chunks/components_windows_projects-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/projects-content.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/components/windows/resume-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_59a978ec.js",
  "static/chunks/_4883083a._.js",
  "static/chunks/components_windows_resume-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/resume-content.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/components/windows/socials-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_2a362fbc._.js",
  "static/chunks/components_windows_socials-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/socials-content.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/components/windows/interests-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_fb2ddefe._.js",
  "static/chunks/components_windows_interests-content_tsx_02d83e1e._.js",
  "static/chunks/components_windows_interests-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/interests-content.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/components/windows/ambitions-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_985605d3._.js",
  "static/chunks/components_windows_ambitions-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/ambitions-content.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/components/windows/contact-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_b5192081._.js",
  "static/chunks/components_windows_contact-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/contact-content.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/components/windows/documents-content.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_d4d60651._.js",
  "static/chunks/components_windows_documents-content_tsx_dfb8dbd4._.js",
  "static/chunks/components_windows_documents-content_tsx_9d5b4f83._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/documents-content.tsx [app-client] (ecmascript)");
    });
});
}),
]);
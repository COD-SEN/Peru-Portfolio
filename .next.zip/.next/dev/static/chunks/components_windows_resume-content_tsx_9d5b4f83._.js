(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_59a978ec.js",
  "static/chunks/_4883083a._.js"
],
    source: "dynamic"
});

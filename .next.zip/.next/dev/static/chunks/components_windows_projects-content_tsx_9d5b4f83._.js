(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_677a1f75._.js",
  "static/chunks/components_windows_projects-content_tsx_b3837985._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_windows_09fa44e0._.js",
  "static/chunks/_375545cb._.js",
  "static/chunks/node_modules_f14114d5._.js"
],
    source: "dynamic"
});

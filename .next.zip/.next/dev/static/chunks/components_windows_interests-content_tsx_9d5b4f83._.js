(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_fb2ddefe._.js",
  "static/chunks/components_windows_interests-content_tsx_02d83e1e._.js"
],
    source: "dynamic"
});

module.exports = [
"[project]/components/windows/profile-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_414b75ac._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/profile-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/components/windows/projects-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_e2b8711e._.js",
  "server/chunks/ssr/components_windows_projects-content_tsx_3c79e072._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/projects-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/components/windows/resume-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_jspdf_dist_jspdf_node_min_2cde5503.js",
  "server/chunks/ssr/_d4951c46._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/resume-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/components/windows/socials-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_4af05044._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/socials-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/components/windows/interests-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_565d3d60._.js",
  "server/chunks/ssr/components_windows_interests-content_tsx_15dac065._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/interests-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/components/windows/ambitions-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_062e54b5._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/ambitions-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/components/windows/contact-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_267c73fe._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/contact-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/components/windows/documents-content.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_58ea7fbd._.js",
  "server/chunks/ssr/components_windows_documents-content_tsx_f3a97803._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/windows/documents-content.tsx [app-ssr] (ecmascript)");
    });
});
}),
];